﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace Vecpredstavnost2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
   

    public partial class MainWindow : Window
    {

        Bitmap image1;

        short [,]array = new short[16,16];
        short[,] predikcija = new short[1, 1];
        int[] zigzagIndexs = { 0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 };
        StringBuilder binKodirano = new StringBuilder(); // podobno kot string

        public MainWindow()

        {
            InitializeComponent();
           
        }

           private double[,] FDCT(short[,] razlika) {

            double[,] FDCT_vrednost = new double[8, 8];
             
         
            double c1, c2;
            for (int u = 0; u < 8; u++) {
                for (int v = 0; v < 8; v++) {

                    if (u == 0)
                    {
                        c1 = 1 / Math.Sqrt(2);

                    }
                    else
                    {
                        c1 = 1;
                    }
                    if (v == 0)
                    {
                        c2 = 1 / Math.Sqrt(2);

                    }
                    else
                    {
                        c2 = 1;
                    }
                    double tmp = 0;
                    for (int x = 0; x < 8; x++)
                    {
                        for (int y = 0; y < 8; y++)
                        {

                            tmp += array[x, y] * Math.Cos(((2 * x + 1) * u * Math.PI) / 16) * Math.Cos(((2 * x + 16) * v * Math.PI) / 1);


                        }

                    }
                    FDCT_vrednost[u, v] = 1 / 4 * c1 * c2 * tmp;
                }
            }


            return FDCT_vrednost;

           }


        private double[,] IDCT(int [,] razlika)
        {
            double[,] IDCT_vrednost = new double[8, 8];


            double c1, c2;
            for (int x = 0; x < 8; x++) {
                for (int y = 0; y < 8; y++) {

                    double tmp = 0;
                    for (int u = 0; u < 8; u++)
                    {
                        for (int v = 0; v < 8; v++)
                        {


                            if (u == 0)
                            {
                                c1 = 1 / Math.Sqrt(2);

                            }
                            else
                            {
                                c1 = 1;
                            }
                            if (v == 0)
                            {
                                c2 = 1 / Math.Sqrt(2);

                            }
                            else
                            {
                                c2 = 1;
                            }

                            tmp += c1 * c2 * array[x, y] * Math.Cos(((2 * x + 1) * u * Math.PI) / 16) * Math.Cos(((2 * x + 1) * v * Math.PI) / 16);


                        }
                    }
                    IDCT_vrednost[x, y] = 1 / 4 * tmp;
                }
             }

            

            return  IDCT_vrednost;


        }

        //kompresija
        void kompresija() {
            short[,] tmp = new short[8, 8];

            for (int i = 0; i < image1.Width; i += 8 )
                for( int x= 0;x< 8; x++) {
                    for (int y = 0; y < 8; y++) {

                        tmp[x, y] = array[x, y+i];
                    }
                }
            izhodni_niz(FDCT(tmp));
            //levi rob
            for (int i = 8; i < image1.Height; i += 8)
                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {

                        tmp[x, y] = array[x+i, y];
                    }
                }

            izhodni_niz(FDCT(tmp));





        }


        void izhodni_niz(double[,] matrika) {
            int[] matrika1D = new int [64];
            int x, y;

            for (int i = 0; i < 64; i++) {
                y = zigzagIndexs[i] % 8;
                x = zigzagIndexs[i] / 8;
                matrika1D[i] = Convert.ToInt32(Math.Round(matrika[x, y]));

            }
            if (matrika1D[0] < 0)
            {
                binKodirano.Append("0");

            }
            else {
                binKodirano.Append("1");

            }

            binKodirano.Append(Convert.ToString(Math.Abs(matrika1D[0]), 2).PadLeft(11, '0')); // v kolikor nebo dolg 11 bo dal 0 na zacetek da pride do 12 znakov ** dvojiski komplement

            int st_nul = 0;
            for (int i = 1; i < 64; i++) {
                if (matrika1D[i] == 0)
                {
                    st_nul++;
                }
                else {

                    if (st_nul == 0) // tip C
                    {
                        binKodirano.Append("1");
                    }
                    else {
                        //tip a
                        binKodirano.Append("0");
                        binKodirano.Append(Convert.ToString(st_nul, 2).PadLeft(6, '0'));
                        st_nul = 0;


                    }
                    //tekoca dolzina
                    string tmp = Convert.ToString(Math.Abs(matrika1D[i]), 2);
                    binKodirano.Append(Convert.ToString(tmp.Length + 1, 2).PadLeft(4, '0'));
                    if (matrika1D[i] < 0)
                    {
                        binKodirano.Append(("0" + tmp));
                    }
                    else {
                        binKodirano.Append(("1" + tmp));

                    }

                }

            }

            //tip b 
            if (st_nul != 0) {
                binKodirano.Append("0" + Convert.ToString(st_nul, 2).PadLeft(6, '0'));


            }


        }








        public static Bitmap nekaj(BitmapImage image) {
            using (MemoryStream ms = new MemoryStream())
            {
                BmpBitmapEncoder encoder = new BmpBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(image));
                encoder.Save(ms);
                Bitmap bitmap = new Bitmap(ms);
                return new Bitmap(bitmap);

            }
        }

private void btnLoad_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.InitialDirectory = "c:\\";
            dlg.Filter = "Image files All Files (*.*)|*.*";
           

            if (dlg.ShowDialog() == true)
            {
                string selectedFileName = dlg.FileName;
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                imgPhoto.Source = bitmap;

                image1 = nekaj(bitmap);
                array = new short[Convert.ToInt16(bitmap.Width), Convert.ToInt16(bitmap.Height)];
                predikcija = new short[Convert.ToInt16(bitmap.Width), Convert.ToInt16(bitmap.Height)];


                // napolnimo polje 2D polje z
                for (int x = 0; x < image1.Width; x++) {
                    for (int y = 0; y < image1.Height; y++) {
                        System.Drawing.Color tmpBarva = image1.GetPixel(x,y);

                        array[x, y] = tmpBarva.R;
                        array[x, y] -= 128;

           

                    }
                }

                kompresija();


                if (binKodirano.Length % 8 != 0) {
                    binKodirano.Append('0');
                    

                }
                //shranimo
                int numberOfBytes = binKodirano.Length / 8;
                byte[] bytes1 = new byte[numberOfBytes];
                for (int i = 0; i < numberOfBytes; i++) {
                    bytes1[i] = Convert.ToByte(binKodirano.ToString(8 * i, 8), 2);

                }
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = " File| *.aleks";
                if (sfd.ShowDialog() == true) {
                    File.WriteAllBytes(sfd.FileName, bytes1);
                }





            }
        }

        //DEKODIRANJE:

        private void btn_dekod(object sender, RoutedEventArgs e) {

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = " file *.aleks|*.aleks";
            if (ofd.ShowDialog() == true) {
                StringBuilder builder = new StringBuilder();
                byte[] bytes = File.ReadAllBytes(ofd.FileName);
                for (int i = 0; i < bytes.Length; i++) {
                    builder.Append(Convert.ToString(bytes[i], 2).PadLeft(8, '0'));
                }
                binKodirano= builder;
                
            }



        }


  
        int width = 0;
        int height = 0;
        int index = 32; 
        int [,] vreDekodiranihPixlov =  new int[1,1];

          int[,] ustvari_matriko() {
            int st_kof = 1;
            int[,] tmpMatrika = new int[8,8];
            int[] tmpPolje = new int[64];
            tmpPolje[0] = Convert.ToInt32(binKodirano.ToString(index + 1, 11),2);
            if (binKodirano[index] == '0') {
                tmpPolje[0] *= -1;
            }
            index += 12;

           /* while (st_kof < 64)
            {


                if (binKodirano[index] == '1')
                {
                    int dolzina = Convert.ToInt32(binKodirano.ToString(index + 1, 4), 2);

                    tmpPolje[st_kof] = Convert.ToInt32(binKodirano.ToString(index + 1, 4), 2);

                    if (binKodirano[index + 5] == '0')
                    {
                        tmpPolje[st_kof] *= -1;
                    }
                    index += 5 + dolzina;
                    st_kof++;

                }
                else {

                    int tek_dolzina = Convert.ToInt32(binKodirano.ToString(index + 1, 6), 2);
                    st_kof += tek_dolzina;

                    if (st_kof >= 64) {
                        index += 7;
                        break;

                    }
                    int dolzina = Convert.ToInt32(binKodirano.ToString(index + 7, 4), 2);
                    tmpPolje[st_kof] = Convert.ToInt32(binKodirano.ToString(index + 12, dolzina - 1), 2);

                    if (binKodirano[index + 11] == '0') {

                        tmpPolje[st_kof] *= -1;

                    }
                    st_kof++;
                    index += dolzina + 11;

                }
            }
            int stolpec = 0;
            int vrsta = 0;
            for(int i = 0; i < 64; i++)
            {

                stolpec = zigzagIndexs[i] % 8;
                vrsta = zigzagIndexs[i] / 8;
                tmpMatrika[vrsta, stolpec] = tmpPolje[i];
            }*/
            
            return tmpMatrika;


          }

        void izhodni_niz() {
            width = Convert.ToInt32(binKodirano.ToString(0, 16), 2);
            height = Convert.ToInt32(binKodirano.ToString(16, 16), 2);
            vreDekodiranihPixlov = new int[width, height];

            double[,] Matrika = new double[8, 8];

            for (int x = 0; x < width; x += 8) {

                Matrika = IDCT(ustvari_matriko());
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {

                        vreDekodiranihPixlov[i, j + x] = (int)Math.Round(Matrika[i, j]);
                    }
                }
            }




        }


        void dekodiraj() {

            for (int x = 8; x < width; x++) {

                for (int y = 8; y < height; y += 8) {

                    int[,] tmpMatrika = new int[8, 8];

                    index += 2;
                    double[,] vmesnaM = IDCT(ustvari_matriko());
                    for (int i = 0; i < 8; i++) {

                        for (int j = 0; j < 8; j++) {
                            tmpMatrika[i, j] = (int)Math.Round(vmesnaM[i, j]);
                        }
                    }
                    ///

                }

            }

        }






    }
}
